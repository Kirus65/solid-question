
<div id="si">    
    <img src="Memecorazon.jpg" width="70%">
    <h2>Gracias bb, lo sabía. Feliz primer día de novios.</h2>
</div>